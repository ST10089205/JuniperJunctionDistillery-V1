package com.example.juniperjunctiondistillery.models

class SupplierCategoryModel {
    var SupplierCategoryID : String=""
    var SupplierCategory : String=""

    constructor()
    constructor(SupplierCategoryID: String, SupplierCategory: String) {
        this.SupplierCategoryID = SupplierCategoryID
        this.SupplierCategory = SupplierCategory
    }


}